import UIKit
import XCTest

class StringCalculator {

    enum AdditionError: Error {
            case NegativeNumbersUnsupported
    }
    
    func Add(numbers:String) throws -> Int {
        
        //Empty string handling
        if numbers.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return 0 }
        
        //Delimeter handling
        let controlCode = "//"
        var delimeter = ","
        if numbers.starts(with: controlCode) {
            delimeter = String(numbers[String.Index.init(utf16Offset: 2, in: numbers)])
        }

        //String to array convert
        var arr = numbers.components(separatedBy: .whitespacesAndNewlines)
                         .joined()
                         .components(separatedBy: delimeter)
                         .compactMap({ Int($0) })
        let negativeArr = arr.filter({ $0 < 0 })
        
        
        //Negative number handling
        if negativeArr.count > 0 {
            throw AdditionError.NegativeNumbersUnsupported
        }
        
        arr = arr.filter { $0 < 1000 }
        
        // sum of array
        let sum = arr.reduce(0, +)
        
        return sum
    }

}


/**************************  TESTS ********************/
//MARK: TESTS
class StringCalculatorTest: XCTestCase{
    
    //MARK:- Empty input should return 0
    func testEmptyInput() {
        do{
            let num = try StringCalculator().Add(numbers: "")
            XCTAssertEqual(num, 0)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    //MARK:- Single number should return same number
    func testSingleNumber() {
        do{
            let num = try StringCalculator().Add(numbers: "5")
            XCTAssertEqual(num, 5)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    //MARK:- Two numbers with commas should return sum
    func testTwoNumber() {
        do{
            let num = try StringCalculator().Add(numbers: "5,6")
            XCTAssertEqual(num, 11)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    
    //MARK:- Invalid input should return 0
    func testInvalidInput() {
        do{
            let num = try StringCalculator().Add(numbers: "1;2;3;4")
            XCTAssertEqual(num, 0)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    //MARK:- Ten numbers with commas should return sum
    func testTenNumbers() {
        do{
            let num = try StringCalculator().Add(numbers: "1,\n2,\n3,\n4,\n5,\n6,\n7,\n8,\n9,\n10")
            XCTAssertEqual(num, 55)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    
    //MARK:- Negatives should produce an exception
    func testNegativeNumbers() {
        if let _ = try? StringCalculator().Add(numbers: "2,-3") {
                XCTFail("no error thrown")
        }else{
            XCTFail("Negative Numbers not allowed")
        }
    }
    
    //MARK:- Ignore Number greater then 1000
    func testGreaterNumberSkip() {
        do{
            let num = try StringCalculator().Add(numbers: "2,1001")
            XCTAssertEqual(num, 2)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
    
    
    //MARK:- Delimiters can be arbitrary length
    func testDelimetersArbitraryLength() {
        do{
            let num = try StringCalculator().Add(numbers: "//***\n1***2***3")
            XCTAssertEqual(num, 6)
        }catch let error {
            XCTAssertThrowsError(error.localizedDescription)
        }
        
    }
}

StringCalculatorTest.defaultTestSuite.run()
